package net.sf.robocode.battle;


public abstract class Command {

	public void execute() {}
}
