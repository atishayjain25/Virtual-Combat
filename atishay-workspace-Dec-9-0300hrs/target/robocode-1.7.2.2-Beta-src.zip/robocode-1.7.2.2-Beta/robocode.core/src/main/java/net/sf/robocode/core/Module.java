/*******************************************************************************
 * Copyright (c) 2001, 2008 Mathew A. Nelson and Robocode contributors
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://robocode.sourceforge.net/license/cpl-v10.html
 *
 * Contributors:
 *     Pavel Savara
 *     - Initial implementation
 *******************************************************************************/
package net.sf.robocode.core;


import net.sf.robocode.peer.*;
import net.sf.robocode.serialization.RbSerializer;
import net.sf.robocode.settings.ISettingsManager;
import net.sf.robocode.settings.SettingsManager;
import net.sf.robocode.version.IVersionManager;
import net.sf.robocode.version.VersionManager;


/**
 * @author Pavel Savara (original)
 */
public class Module {
	static {
		Container.cache.addComponent(RobocodeMain.class);
		Container.cache.addComponent(IVersionManager.class, VersionManager.class);
		Container.cache.addComponent(ISettingsManager.class, SettingsManager.class);
		initSerializer();
	}

	private static void initSerializer() {
		RbSerializer.register(ExecCommands.class, RbSerializer.ExecCommands_TYPE);
		RbSerializer.register(BulletCommand.class, RbSerializer.BulletCommand_TYPE);
		RbSerializer.register(TeamMessage.class, RbSerializer.TeamMessage_TYPE);
		RbSerializer.register(DebugProperty.class, RbSerializer.DebugProperty_TYPE);
		RbSerializer.register(ExecResults.class, RbSerializer.ExecResults_TYPE);
		RbSerializer.register(BulletStatus.class, RbSerializer.BulletStatus_TYPE);
	}
}
